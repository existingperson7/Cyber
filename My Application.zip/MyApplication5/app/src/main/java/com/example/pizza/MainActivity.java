
package com.example.pizza;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText etName;
    EditText etPhone;
    Button btnContinue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etPhone = findViewById(R.id.etPhone);
        btnContinue = findViewById(R.id.btnContinue);

        btnContinue.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        if (view.getId() == R.id.btnContinue) {

            String name = etName.getText().toString().trim();
            String phone = etPhone.getText().toString().trim();

            if (name.isEmpty() || phone.isEmpty()) {

                Toast.makeText(
                        this,
                        "You must enter name and phone number",
                        Toast.LENGTH_LONG
                ).show();

            } else {

                Toast.makeText(
                        this,
                        name + ", " + phone,
                        Toast.LENGTH_LONG
                ).show();

                Intent i = new Intent(MainActivity.this, MainActivity2.class);

                i.putExtra("NAME", name);
                i.putExtra("PHONE", phone);

                startActivity(i);
            }
        }
    }
}
