
    package com.example.pizza;

    import android.content.Intent;
    import android.os.Bundle;
    import android.view.View;
    import android.widget.Button;
    import android.widget.CheckBox;
    import android.widget.RadioButton;
    import android.widget.TextView;

    import androidx.appcompat.app.AppCompatActivity;

    public class MainActivity2 extends AppCompatActivity implements View.OnClickListener {

        TextView tvWelcome, tvInfo, tvPrice;
        String name = "", phone = "";

        Button btnContinue;

        RadioButton rbLarge, rbSmall;

        CheckBox cbMushrooms, cbOlives, cbOnions, cbExtraCheese, cbPineapple, cbCorn;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main2);

            tvWelcome = findViewById(R.id.tvWelcome);
            tvInfo = findViewById(R.id.tvInfo);
            tvPrice = findViewById(R.id.tvPrice);

            btnContinue = findViewById(R.id.btnContinue);

            rbLarge = findViewById(R.id.rbLarge);
            rbSmall = findViewById(R.id.rbSmall);

            cbMushrooms = findViewById(R.id.cbMushrooms);
            cbCorn = findViewById(R.id.cbCorn);
            cbOlives = findViewById(R.id.cbOlives);
            cbOnions = findViewById(R.id.cbOnions);
            cbPineapple = findViewById(R.id.cbPineapple);
            cbExtraCheese = findViewById(R.id.cbExtraCheese);

            Intent i = getIntent();

            if (i != null) {
                name = i.getStringExtra("NAME");
                phone = i.getStringExtra("PHONE");
            }

            tvWelcome.setText("Welcome, " + name);

            btnContinue.setOnClickListener(this);

            rbLarge.setOnClickListener(this);
            rbSmall.setOnClickListener(this);
            rbSmall.setChecked(true);

            cbMushrooms.setOnClickListener(this);
            cbCorn.setOnClickListener(this);
            cbOlives.setOnClickListener(this);
            cbOnions.setOnClickListener(this);
            cbPineapple.setOnClickListener(this);
            cbExtraCheese.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {

            String toppings = "";
            int price = 0;

            if (rbLarge.isChecked()) {
                price += 60;
                toppings += "Large pizza with ";
            }

            if (rbSmall.isChecked()) {
                price += 30;
                toppings += "Small pizza with ";
            }

            if (cbCorn.isChecked()) {
                price += 5;
                toppings += "corn ";
            }

            if (cbMushrooms.isChecked()) {
                price += 5;
                toppings += "mushrooms ";
            }

            if (cbOlives.isChecked()) {
                price += 5;
                toppings += "olives ";
            }

            if (cbOnions.isChecked()) {
                price += 5;
                toppings += "onions ";
            }

            if (cbPineapple.isChecked()) {
                price += 5;
                toppings += "pineapple ";
            }

            if (cbExtraCheese.isChecked()) {
                price += 5;
                toppings += "cheese ";
            }

            tvPrice.setText("Price: " + price + "$");

            if (view.getId() == R.id.btnContinue) {
                Intent i = new Intent(this, MainActivity3.class);
                i.putExtra("PRICE", price);
                i.putExtra("TOPPINGS", toppings);
                i.putExtra("NAME", name);
                i.putExtra("PHONE", phone);
                startActivity(i);
            }
        }
    }
