
package com.example.pizza;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity4 extends AppCompatActivity {

    String name = "", phone = "", toppings = "";
    int price;

    TextView tvWelcome, tvPrice, tvToppings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        // Connect TextViews
        tvWelcome = findViewById(R.id.tvWelcome);
        tvPrice = findViewById(R.id.tvPrice);
        tvToppings = findViewById(R.id.tvToppings);

        // Get information from previous screen
        Intent i = getIntent();

        if (i != null) {
            name = i.getStringExtra("NAME");
            phone = i.getStringExtra("PHONE");
            price = i.getIntExtra("PRICE", 0);
            toppings = i.getStringExtra("TOPPINGS");
        }

        // Prevent null values
        if (name == null) name = "";
        if (phone == null) phone = "";
        if (toppings == null) toppings = "";

        // Display information
        tvWelcome.setText("Welcome " + name + ", " + phone);

        tvPrice.setText("Price: " + price + "$");

        tvToppings.setText("Your toppings:\n" + toppings);
    }
}
