package com.example.pizza;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.net.Socket;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.io.InputStreamReader;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity3 extends AppCompatActivity implements View.OnClickListener {
    String name = "", phone = "", toppings = "";
    int price;

    TextView tvPrice, tvInfo;

    Button btnFinish, btnChange;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        Intent i = getIntent();

        if (i != null) {
            name = i.getStringExtra("NAME");
            phone = i.getStringExtra("PHONE");
            price = i.getIntExtra("PRICE", 0);
            toppings = i.getStringExtra("TOPPINGS");
        }

        tvPrice = findViewById(R.id.tvPrice);
        tvPrice.setText("Price: " + price + "$");
        tvInfo = findViewById(R.id.tvInfo);
        tvInfo.setText("Welcome " + name + ", " + phone);

        btnChange = findViewById(R.id.btnChange);
        btnChange.setOnClickListener(this);
        btnFinish = findViewById(R.id.btnFinish);
        btnFinish.setOnClickListener(this);
    }

    public void onClick(View view) {
        if (view.getId() == R.id.btnChange) {
            finish();
        }
        if (view.getId() == R.id.btnFinish) {
            sendOrder();
        }
    }

    private void sendOrder() {
        new Thread(() -> {
            try {
                String serverIP = "192.168.4.95";
                int port = 12345;

                Socket socket = new Socket(serverIP, port);

                PrintWriter out = new PrintWriter(
                        socket.getOutputStream(), true
                );

                BufferedReader in = new BufferedReader(
                        new InputStreamReader(socket.getInputStream())
                );

                // Send order to Python
                String message = name + "," + phone + "," +
                        price + "," + toppings;

                out.println(message);

                // Wait for Python's answer
                String answer = in.readLine();

                if ("1".equals(answer)) {
                    Intent i = new Intent(this, MainActivity4.class);
                    i.putExtra("PRICE", price);
                    i.putExtra("TOPPINGS", toppings);
                    i.putExtra("NAME", name);
                    i.putExtra("PHONE", phone);
                    startActivity(i);
                }

                socket.close();

            } catch (Exception e) {
                e.printStackTrace();

                runOnUiThread(() ->
                        tvInfo.setText("Connection error!")
                );
            }
        }).start();
    }
}